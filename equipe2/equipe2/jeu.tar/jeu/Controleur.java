package jeu;

import jeu.ihm.FramePrincipale;
import jeu.metier.GestionnairePlateau;

public class Controleur
{

	private FramePrincipale     ihm;
	private GestionnairePlateau metier;
	

	public Controleur()
	{
		this.ihm = new FramePrincipale ( this );
		thi
	}





	public static void main (String[] args)
	{
		new Controleur();
	}
}